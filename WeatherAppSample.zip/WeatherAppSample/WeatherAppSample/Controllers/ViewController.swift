//
//  ViewController.swift
//  WeatherAppSample
//
//  Created by Kavya Mangala muppidi on 3/22/21.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var enterCityTextField: UITextField!
    @IBOutlet weak var lookUpButtonField: UIButton!
    @IBOutlet weak var loaderView: UIView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    var weatherData: WeatherResponse?

    override func viewDidLoad() {
        super.viewDidLoad()
        hideNavigationBar()
        configureButtonDesign()
    }
    
    func hideNavigationBar() {
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = true
        self.navigationController?.navigationBar.backgroundColor = UIColor.lightGray
    }
    
    func configureButtonDesign() {
        lookUpButtonField.layer.cornerRadius = 13
        lookUpButtonField.layer.borderColor = UIColor.black.cgColor
        lookUpButtonField.layer.borderWidth = 1
    }
    
    @IBAction func lookupButtonActionn(_ sender: Any) {
         self.view.endEditing(true)
        guard let cityName = enterCityTextField.text, !cityName.isEmpty else {
            return
        }
        enterCityTextField.text = nil
        loaderView.isHidden = false
        ApiManager.shared.weatherReport(cityName) { [weak self] (response, status) in
            DispatchQueue.main.async {
                self?.loaderView.isHidden = true
                if status {
                    self?.weatherData = response as? WeatherResponse
                    self?.performSegue(withIdentifier: "listPage", sender: nil)
                } else {
                    self?.showAlertMessage(message: "Error! Something went wrong, Please try again.")
                }
            }
        }
    }
    
    func showAlertMessage(title:String = "", message:String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        self.present(alert, animated: true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "listPage" {
            guard let weatherData = self.weatherData else { return }
            guard let listView = segue.destination as? ListTableViewController else { return }
            listView.cityName = weatherData.city?.name
            listView.datasource = weatherData.list
            navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        }
    }
}

extension ViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
}

