//
//  DetailsViewController.swift
//  WeatherAppSample
//
//  Created by Kavya Mangala muppidi on 3/22/21.
//

import UIKit

class DetailsViewController: UIViewController {
    
    var weather: List?
    
    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var feelsLikeLabel: UILabel!
    @IBOutlet weak var weatherLabel: UILabel!
    @IBOutlet weak var weatherDescriptionLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       configureWeatherDetails()
    }
    
    func configureWeatherDetails() {
        tempLabel.text = "\(weather?.main?.temp ?? 0)"
        feelsLikeLabel.text = "Feels Like: \(weather?.main?.feelsLike ?? 0)"
        weatherLabel.text = "\(weather?.weather?.first?.main ?? "")"
        weatherDescriptionLabel.text = "\(weather?.weather?.first?.description ?? "")"
    }
}
