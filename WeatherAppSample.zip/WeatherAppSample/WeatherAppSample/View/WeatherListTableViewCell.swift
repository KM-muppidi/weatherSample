//
//  ListTableViewCell.swift
//  WeatherAppSample
//
//  Created by Kavya Mangala muppidi on 3/22/21.
//

import UIKit

class WeatherListTableViewCell: UITableViewCell {

    @IBOutlet weak var weatherLabel: UILabel!
    @IBOutlet weak var tempLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
