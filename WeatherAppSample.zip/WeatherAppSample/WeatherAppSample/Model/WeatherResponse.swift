//
//  WeatherResponse.swift
//  WeatherAppSample
//
//  Created by Kavya Mangala muppidi on 3/22/21.
//

import Foundation

struct WeatherResponse : Codable {
    let cod : String?
    let message : Int?
    let cnt : Int?
    let list : [List]?
    let city : City?

    enum CodingKeys: String, CodingKey {

        case cod = "cod"
        case message = "message"
        case cnt = "cnt"
        case list = "list"
        case city = "city"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        cod = try values.decodeIfPresent(String.self, forKey: .cod)
        message = try values.decodeIfPresent(Int.self, forKey: .message)
        cnt = try values.decodeIfPresent(Int.self, forKey: .cnt)
        list = try values.decodeIfPresent([List].self, forKey: .list)
        city = try values.decodeIfPresent(City.self, forKey: .city)
    }

}

struct City : Codable {
    let id : Int?
    let name : String?
    let coord : Coord?
    let country : String?
    let population : Int?
    let timezone : Int?
    let sunrise : Int?
    let sunset : Int?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case name = "name"
        case coord = "coord"
        case country = "country"
        case population = "population"
        case timezone = "timezone"
        case sunrise = "sunrise"
        case sunset = "sunset"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        coord = try values.decodeIfPresent(Coord.self, forKey: .coord)
        country = try values.decodeIfPresent(String.self, forKey: .country)
        population = try values.decodeIfPresent(Int.self, forKey: .population)
        timezone = try values.decodeIfPresent(Int.self, forKey: .timezone)
        sunrise = try values.decodeIfPresent(Int.self, forKey: .sunrise)
        sunset = try values.decodeIfPresent(Int.self, forKey: .sunset)
    }
}

struct Clouds : Codable {
    let all : Int?
}

struct Coord : Codable {
    let lat : Double?
    let lon : Double?
}

struct List : Codable {
    let dt : Int?
    let main : Main?
    let weather : [Weather]?
    let clouds : Clouds?
    let wind : Wind?
    let visibility : Int?
    let pop : Double?
    let sys : Sys?
    let dtTxt : String?

    enum CodingKeys: String, CodingKey {

        case dt = "dt"
        case main = "main"
        case weather = "weather"
        case clouds = "clouds"
        case wind = "wind"
        case visibility = "visibility"
        case pop = "pop"
        case sys = "sys"
        case dtTxt = "dt_txt"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        dt = try values.decodeIfPresent(Int.self, forKey: .dt)
        main = try values.decodeIfPresent(Main.self, forKey: .main)
        weather = try values.decodeIfPresent([Weather].self, forKey: .weather)
        clouds = try values.decodeIfPresent(Clouds.self, forKey: .clouds)
        wind = try values.decodeIfPresent(Wind.self, forKey: .wind)
        visibility = try values.decodeIfPresent(Int.self, forKey: .visibility)
        pop = try values.decodeIfPresent(Double.self, forKey: .pop)
        sys = try values.decodeIfPresent(Sys.self, forKey: .sys)
        dtTxt = try values.decodeIfPresent(String.self, forKey: .dtTxt)
    }

}

struct Main : Codable {
    let temp : Double?
    let feelsLike : Double?
    let tempMin : Double?
    let tempMax : Double?
    let pressure : Int?
    let seaLevel : Int?
    let grndLevel : Int?
    let humidity : Int?
    let tempKf : Double?

    enum CodingKeys: String, CodingKey {

        case temp = "temp"
        case feelsLike = "feels_like"
        case tempMin = "temp_min"
        case tempMax = "temp_max"
        case pressure = "pressure"
        case seaLevel = "sea_level"
        case grndLevel = "grnd_level"
        case humidity = "humidity"
        case tempKf = "temp_kf"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        temp = try values.decodeIfPresent(Double.self, forKey: .temp)
        feelsLike = try values.decodeIfPresent(Double.self, forKey: .feelsLike)
        tempMin = try values.decodeIfPresent(Double.self, forKey: .tempMin)
        tempMax = try values.decodeIfPresent(Double.self, forKey: .tempMax)
        pressure = try values.decodeIfPresent(Int.self, forKey: .pressure)
        seaLevel = try values.decodeIfPresent(Int.self, forKey: .seaLevel)
        grndLevel = try values.decodeIfPresent(Int.self, forKey: .grndLevel)
        humidity = try values.decodeIfPresent(Int.self, forKey: .humidity)
        tempKf = try values.decodeIfPresent(Double.self, forKey: .tempKf)
    }
}

struct Sys : Codable {
    let pod : String?
}

struct Weather : Codable {
    let id : Int?
    let main : String?
    let description : String?
    let icon : String?
}

struct Wind : Codable {
    let speed : Double?
    let deg : Int?
}
    

