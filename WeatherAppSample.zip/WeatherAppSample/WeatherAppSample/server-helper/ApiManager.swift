//
//  ApiManager.swift
//  WeatherAppSample
//
//  Created by Kavya Mangala muppidi on 3/22/21.
//

import Foundation

typealias Completion = (_ response: Any, _ status: Bool) -> Void

enum HttpMethodType: String {
    case get = "GET"
    case post = "POST"
}

let apiKey = "65d00499677e59496ca2f318eb68c049"

class ApiManager: NSObject {
    
    static let shared = ApiManager()
    
    private override init() {}
    
    private func httpRequestWith(httpMethod: HttpMethodType, parameters: [String: Any], urlString: String, completion: @escaping Completion) {
        
        let headers = ["content-type": "application/json", "accept": "application/json",]
        
        let urlString = urlString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        
        var request = URLRequest(url: URL(string: urlString)!)
        request.allHTTPHeaderFields = headers
        request.httpMethod = httpMethod.rawValue
        if httpMethod == .post {
            var postData:Data?
            do {
                try  postData = JSONSerialization.data(withJSONObject: parameters, options: [])
            } catch {
                
            }
            request.httpBody = postData
        }
        
        print(urlString)
        print(parameters)
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            if (error != nil) {
                print(error ?? "")
                completion(String(), false)
            } else {
                
                if let httpResponse = response as? HTTPURLResponse {
                    switch httpResponse.statusCode {
                    case 200..<300:
                        do {
                        let jsonString = try JSONSerialization.jsonObject(with: data!, options: .allowFragments)
                            print(jsonString)
                        } catch {
                            
                        }
                        completion(data ?? Data(), true)
                        break
                    default:
                        completion(Data(), false)
                        break
                    }
                }
                
            }
            }.resume()
    }
 
    func weatherReport(_ city: String, completion: @escaping Completion) {
        let urlString = "https://api.openweathermap.org/data/2.5/forecast?q=\(city)&APPID=\(apiKey)"
        httpRequestWith(httpMethod: .get, parameters: [:], urlString: urlString) { (data, status) in
            if status {
                do {
                    let response = try JSONDecoder().decode(WeatherResponse.self, from: data as! Data)
                    completion(response, true)
                }
                catch let error {
                    print(error)
                    completion(data, false)
                }
            } else {
                completion(data, false)
            }
        }
    }
}
